package com.example.reproductor;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        mediaPlayer=MediaPlayer.create(this,R.raw.riesling_kids);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();



    }
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if  (mediaPlayer!= null)
        {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }
}